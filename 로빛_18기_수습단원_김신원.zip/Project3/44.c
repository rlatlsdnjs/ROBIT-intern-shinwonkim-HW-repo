#include <stdio.h>
#include <math.h>  

int main()
{
    printf("Input Arithmetic Operation\n");
    printf("ex) 3.4 * 8.5\n2.9 - 5.4\n3.9 * 8.0\n3.9 / 8\n2 ^ 3\n\n");

    double a = 0;
    char b = 0;
    double c = 0;

    printf("input: ");
    scanf_s("%lf %c %lf", &a, &b, &c);
       

    switch (b) {
    case '+':
        printf("%lf + %lf = %lf\n", a, c, a + c);
        break;
    case '-':
        printf("%lf - %lf = %lf\n", a, c, a - c);
        break;
    case '*':
        printf("%lf * %lf = %lf\n", a, c, a * c);
        break;
    case '/':
        if (c != 0) {
            printf("%lf / %lf = %lf\n", a, c, a / c);
        }
        else {
            printf("�ٽ� �Է��Ͻÿ�\n");
        }
        break;
    case '^':
        printf("%lf ^ %lf = %lf\n", a, c, pow(a, c));
        break;
    default:
        printf("Invalid operator\n");
    }

    return 0;
}
