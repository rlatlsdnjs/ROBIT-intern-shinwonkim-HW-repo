#include<stdio.h>
int main()
{
	int i;
	int n;
	
	int a = 0;
	int b = 0;
	int c = 1;

	printf("�� �Է�");
	scanf_s("%d", &n);

	for (i = 0; i < n; i++)
	{
		printf("%d", a);
		b = a + c;
		a = c;
		c = b;
	}
	printf("\n\n");


		
	}
